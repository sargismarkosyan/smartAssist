'use strict';
var CronJob = require('cron').CronJob;
var nodemailer = require('nodemailer');
var userService = require('./services/users');
var _ = require('lodash');
var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'smart.assist.test@gmail.com',
    pass: 'smart12Ass'
  }
});

new CronJob("0 */10 * * * *", function() {
  try {
    console.log("\nCRON job started at " + new Date());

    userService.getUsersListEligableForNotification().then(function(users) {
      _.forEach(users[0], function(user) {
        transporter.sendMail({
          to: user.email,
          subject: 'Notification',
          text: 'Hi ' + user.username + ' this is reminder that you have' +
          ' appointment at ' + user.date + ' with doctor ' + user.doctorName
        });
      })
    });

  } catch (err) {
    console.log("Error: " + err);
  }
}, null, true, null);
