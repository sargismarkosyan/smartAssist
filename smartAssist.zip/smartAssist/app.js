var express = require('express');
var bodyParser = require('body-parser');
var alexa = require('alexa-nodekit');
//var session = require('express-session');
var app = express();
var fs = require('fs');
var session, sessionFile;
var cron = require('./cron');
var userService = require('./services/users');
var moment = require('moment');
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());

/*app.use(session({
 secret: '=e76FCK,D8&6l3r`as9Bpl?Kuys3gG=ZM1Ak4]D-@A<AtAo}r49*q+.;^9z*1Y4',
 resave: false,
 saveUninitialized: true,
 genid: function(req) {
 return req.body.session.sessionId;
 }
 }));*/

app.all('*', function(req, res) {
  sessionFile = './sessions/' + req.body.session.sessionId;
  var sessionRead = '';
  session = {};
  if (fs.existsSync(sessionFile)) {
    sessionRead = fs.readFileSync(sessionFile);
    session = sessionRead ? JSON.parse(sessionRead) : session;
  }

  switch (req.body.request.type) {
    case 'LaunchRequest':
      launchRequest(req.body, req, res);
      break;
    case 'IntentRequest':
      intentRequest(req.body, req, res);
      break;
    case 'SessionEndedRequest':
      sessionEndedRequest(req.body, req, res);
      break;
    default:
      res.send('Can\'t parse');
  }
});

app.listen(process.env.PORT || 3000, function() {
  //console.log('Example app listening on port 3000!');
});

function launchRequest(body, req, res) {
  alexa.launchRequest(body);
  // Store the session and/or user data

  // Respond to the Echo
  restart(req);
  return generateResponse(req, res, 'Hello what is your name');
}

function intentRequest(body, req, res) {
  alexa.intentRequest(body);
  // Check session and/or user data
  // Check the Intent Name and Intent Slots to decide on what logic to kick off.

  if (body.request.intent.name === 'AMAZON.RepeatIntent' && session.lastText) {
    return generateResponse(req, res, session.lastText);
  }
  if (body.request.intent.name === 'AMAZON.StopIntent' || body.request.intent.name === 'AMAZON.CancelIntent') {
    return generateResponse(req, res, 'Bye.', true);
  }
  if (body.request.intent.name === 'AMAZON.StartOverIntent') {
    restart(req);
    return generateResponse(req, res, 'What is your name');
  }

  var state = session.state;
  //if (!session.state) session.state = '';

  switch (state) {
    case '':
      if (body.request.intent.name !== 'Alexa' || !body.request.intent.slots.String || !body.request.intent.slots.String.value) {
        return cantUnderstand(req, res);
      }

      session.name = body.request.intent.slots.String.value;
      userService.getUserByName(session.name).then(function(data) {
        var inDb = data[0] && data[0][0] && data[0][0].id;
        if (!inDb) {
          session.state = 'setEmail';
          return generateResponse(req, res, 'Seems you are new customer, please tell me your email.');
        } else {
          session.id = data[0][0].id;
          session.name = data[0][0].name;
          session.state = 'state1';
          var str = 'Welcome back "' + session.name + '".';
          userService.getUserAppointments(session.id).then(function(data) {
            var appointment = data[0] ? data[0][0]: null;
            if (appointment) {
              str += ' Your upcoming appointment in "3" room at "7 pm", doctor "Simonyan"';
            } else {
              session.state = 'createSelectSpec';
              str += ' You have no registered appointment. Which doctor would you like to see.';
            }
            return generateResponse(req, res, str);
          });
        }
      });
      break;
    case 'setEmail':
      if (body.request.intent.name !== 'Alexa' || !body.request.intent.slots.String || !body.request.intent.slots.String.value) {
        return cantUnderstand(req, res);
      }

      var email = body.request.intent.slots.String.value.replace('at', '@').replace('dot', '.').replace(/ /g, '');
      userService.addUser(session.name, email).then(function(data) {
        session.id = data[0].insertId;
        session.state = 'createSelectSpec';
        return generateResponse(req, res, 'You are successfully registered. Which doctor would you like to see.');
      });
      break;
    case 'state1':
      if (body.request.intent.name !== 'Alexa' || !body.request.intent.slots.Actions || !body.request.intent.slots.Actions.value) {
        return cantUnderstand(req, res);
      }
      switch (body.request.intent.slots.Actions.value) {
        case 'create':
          session.state = 'createSelectSpec';
          return generateResponse(req, res, 'Which doctor would you like to see.');
          break;
        case 'select':
          userService.getUserAppointments(session.id).then(function(data) {
            var appointments = data[0];
            if (appointments.length) {
              var str = 'You have following appointments.';
              for (var i = 0; i < appointments.length; i++) {
                str += ' On ' + moment(new Date(appointments[i].date)).format('MMMM DD h m a') + ' in ' + appointments[i].roomN + ' room doctor ' + appointments[i].doctorName + '.';
              }
              return generateResponse(req, res, str);
            } else {
              return generateResponse(req, res, 'You have no registered appointment.');
            }
          });
          break;
        case 'delete':
          if (!body.request.intent.slots.Date || !body.request.intent.slots.Date.value || !body.request.intent.slots.Time || !body.request.intent.slots.Time.value) {
            return cantUnderstand(req, res);
          }
          //@TODO remove from DB
          var wasAppointment = true;
          if (wasAppointment) {
            return generateResponse(req, res, 'Appointment has been removed.');
          } else {
            return generateResponse(req, res, 'No appointment at that time.');
          }
          break;
      }
      break;
    case 'createSelectSpec':
      if (body.request.intent.name !== 'Alexa' || !body.request.intent.slots.Spec || !body.request.intent.slots.Spec.value) {
        return cantUnderstand(req, res);
      }
      //@TODO get earliest appointment date from DB
      session.newAppointmentSpec = body.request.intent.slots.Spec.value;
      session.newAppointmentDate = new Date();
      session.newAppointmentDate.setTime(session.newAppointmentDate.getTime() + (1*60*60*1000));
      session.state = 'createSelectConfirm';
      var date = moment(new Date()).add(Math.floor(Math.random() * 120), 'hours');
      if (date.format('a') === 'pm') {
        date.substract(12, 'hours');
      }
      return generateResponse(req, res, 'The earliest you can see available "' + body.request.intent.slots.Spec.value + '" is ' + date.format('DD of MM h a') + 'tomorrow , would you like to make an appointment?');
      break;
    case 'createSelectConfirm':
      if (body.request.intent.name === 'AMAZON.YesIntent') {
        userService.addAppointment(session.id || 221, 11, moment(new Date(session.newAppointmentDate)).format('YYYY-MM-DD HH:mm:ss')).then(function(data) {
          session.newAppointmentSpec = '';
          session.newAppointmentDate = '';
          session.state = 'state1';
          return generateResponse(req, res, 'Your appointment is registered successfully');
        });
        break;
      }
      if (body.request.intent.name === 'AMAZON.NoIntent') {
        session.newAppointmentDate = '';
        session.state = 'createSelectDate';
        return generateResponse(req, res, 'Please tell your preferred appointment date.');
        break;
      }
      cantUnderstand(req, res);
      break;
    case 'createSelectDate':
      if (body.request.intent.name !== 'Alexa' || !body.request.intent.slots.Date || !body.request.intent.slots.Date.value || !body.request.intent.slots.Time || !body.request.intent.slots.Time.value) {
        return cantUnderstand(req, res);
      }
      var isAvailable = userService.checkAppointment();
      if (isAvailable) {
        userService.addAppointment(session.id || 221, 11, moment(new Date(body.request.intent.slots.Date.value)).format('YYYY-MM-DD HH:mm:ss')).then(function(res) {
          session.state = 'state1';
          return generateResponse(req, res, 'Your appointment is registered successfully.');
        });
      } else {
        return generateResponse(req, res, 'This time is unavailable please select another one.');
      }
      break;
    default:
      return generateResponse(req, res, 'Bye.', true);
  }
}

function sessionEndedRequest(body, req, res) {
  alexa.sessionEndedRequest(body);
  // Check session and delete it.

  // Respond to the Echo
  alexa.response(function(error, response) {
    //session.destroy();
    fs.unlinkSync('./sessions/' + req.body.session.sessionId);

    if (error) {
      return res.status(400).jsonp({message: error});
    }
    return res.jsonp(response);
  });
}

function cantUnderstand(req, res) {
  generateResponse(req, res, 'Can\'t understand, could you answer the question.');
}

function generateResponse(req, res, str, end) {
  session.lastText = str;
  saveSession(req);
  alexa.response(str, {
    title: 'Status',
    subtitle: session.state + ', ' + session.name,
    content: JSON.stringify(session)
  }, !!end, function(error, response) {
    if (error) {
      return res.status(400).jsonp({message: error});
    }
    return res.jsonp(response);
  });
}

/*var firstSubstate = {
 create: {
 selectDoctor: {
 yesCreateAppointment: {},
 noCreateAppointment: {
 whenCreateAppointment: {
 thatAppointmentTimeIsAvailable: {},
 thatAppointmentTimeIsBusy: {
 yesCreateAppointmentTimeIsBusy: {},
 noCreateAppointmentTimeIsBusy: {}
 }
 }
 }
 }
 },
 select: {},
 cancel: {}
 };

 firstSubstate.create.selectDoctor.yesCreateAppointment = firstSubstate;
 firstSubstate.create.selectDoctor.noCreateAppointment.whenCreateAppointment.thatAppointmentTimeIsAvailable = firstSubstate;
 firstSubstate.create.selectDoctor.noCreateAppointment.whenCreateAppointment.thatAppointmentTimeIsBusy.yesCreateAppointmentTimeIsBusy = firstSubstate;
 firstSubstate.create.selectDoctor.noCreateAppointment.whenCreateAppointment.thatAppointmentTimeIsBusy.noCreateAppointmentTimeIsBusy = firstSubstate.create.selectDoctor.noCreateAppointment.whenCreateAppointment;

 states = {
 nameExists: {
 noAppointmentToday: firstSubstate
 },
 nameNotExists: {
 setEmail: firstSubstate.create
 }
 };*/

function restart(req) {
  session.state = '';
  session.name = '';
  session.id = '';
  session.newAppointmentDate = '';
  session.newAppointmentSpec = '';
}

function saveSession(req) {
  fs.writeFileSync('./sessions/' + req.body.session.sessionId, JSON.stringify(session));
}