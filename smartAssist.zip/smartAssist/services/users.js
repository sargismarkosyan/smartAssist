var connection = require('../config/db.js'),
    promise = require('bluebird');

exports.getUserAppointments = function(userId) {
  return new promise(function(resolve, reject) {
    connection.raw('SELECT S.*, D.name' +
        ' as doctorName, D.roomN FROM shcedule as S Join user as U on' +
        ' S.user_id = U.id Join doctor as D on S.doctor_id = D.id WHERE U.id = ' + userId).then(function(result) {
      resolve(result);
    }).catch(function(err) {
      reject(err);
    });
  });
};
exports.getUsersListEligableForNotification = function() {
  return new promise(function(resolve, reject) {
    connection.raw('SELECT date, U.name as username, U.email as email, D.name' +
            ' as doctorName, D.roomN FROM shcedule as S Join user as U on' +
            ' S.user_id = U.id Join doctor as D on S.doctor_id = D.id WHERE date> NOW()')
        .then(function(result) {
          resolve(result);
        }).catch(function(err) {
      reject(err);
    });
  });
};

exports.getUserByName = function(name) {
  return new promise(function(resolve, reject) {
    connection.raw('SELECT * FROM user WHERE name ="' + name + '"')
        .then(function(result) {
          resolve(result);
        }).catch(function(err) {
      reject(err);
    });
  });
};

exports.addUser = function(name, email) {
  return new promise(function(resolve, reject) {
    var sql = 'INSERT INTO `smartassist`.`user` (`name`, `email`) VALUES ("' + name + '","' + email + '");';
    connection.raw(sql)
        .then(function(result) {
          resolve(result);
        }).catch(function(err) {
      reject(err);
    });
  });//INSERT INTO `smartassist`.`user` (`name`, `email`) VALUES ('2222',
  // '2222');
};

exports.addAppointment = function(userId, doctorId, date) {
  return new promise(function(resolve, reject) {
    var sql = 'INSERT INTO shcedule (doctor_id, user_id, date) VALUES ("' + doctorId + '","' + userId + '","' + date + '")';
    connection.raw(sql)
        .then(function(result) {
          resolve(result);
        }).catch(function(err) {
      reject(err);
    });
  });
};
exports.checkAppointment = function() {
  return !!getRandomIntInclusive(0, 1);
};

function getRandomIntInclusive(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}