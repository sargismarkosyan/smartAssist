var knex = require('knex');
var connection = knex({
  client: 'mysql',
  connection: {
    host     : 'eu-cdbr-azure-west-d.cloudapp.net',
    user     : 'b6ed333d225c3e',
    password : '202a35ae',
    database : 'smartAssist'
  }
});
module.exports = connection;
